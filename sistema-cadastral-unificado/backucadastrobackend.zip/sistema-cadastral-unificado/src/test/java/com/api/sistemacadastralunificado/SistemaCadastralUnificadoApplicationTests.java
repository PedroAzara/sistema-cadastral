package com.api.sistemacadastralunificado;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemaCadastralUnificadoApplicationTests {

	@Test
	void contextLoads() {
	}

}
